<?php
try{
    $bdd = new PDO('mysql:host=localhost;dbname=tp4_php_test;charset=utf8','root','');
    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
}catch(Exception $e){
    die('Erreur :'.$e->getMessage());
}
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Inscription</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body>
    <center>
    <h1> Inscription :</h1>
    <form method="POST" action="inscription.php">
    <label for="pseudo">Pseudo : </label><input type="text" name="pseudo" id="pseudo"/><br><br>
    <label for="mdp">Mot de passe : </label><input type="password" name="mdp" id="mdp"/><br><br>
    <label for="confi_mdp">Pseudo : </label><input type="password" name="confi_mdp" id="confi_mdp"/><br><br>
    <label for="email">Email : </label><input type="text" name="email" id="email"/><br><br>
    <input type="submit"/><br><br>

    <?php
    if(isset($_POST['pseudo']) && isset($_POST['mdp']) && isset($_POST['confi_mdp']) && isset($_POST['email']) && $_POST['pseudo']!=NULL && $_POST['mdp']!=NULL && $_POST['confi_mdp']!=NULL && $_POST['email']!=NULL){
        $req = $bdd->prepare('select count(*) as nbr from membres where pseudo=?');
        $req->execute(array($_POST['pseudo']));
        $donne = $req->fetch(PDO::FETCH_ASSOC);
        if($donne['nbr'] != 0){
            echo 'Pseudo dejà utilisé';?> <br> <?php
        }else{
            if($_POST['confi_mdp'] != $_POST['mdp']){
                echo 'Mot de passe différent par rapport à la confimration';?> <br> <?php
            }else{
                if(preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#",$_POST['email'])){
                        $pass_hach = password_hash($_POST['mdp'],PASSWORD_DEFAULT);
                        $req = $bdd->prepare('insert into membres (pseudo,pass,email,date_inscription) values (:pseudo,:pass,:email,now())');
                        $req->execute(array('pseudo' => $_POST['pseudo'],
                        'pass' => $pass_hach,
                        'email' => $_POST['email'],
                        ));
                        echo 'insciption reussi';
                        header('location: connexion.php');
                }else{
                    echo 'Adresse email non valide';?> <br> <?php
                }
            }
        }
    }else{
        echo 'Un ou plusieurs champs sont vide';?> <br> <?php
    }
    ?>

    </center>
</body>
</html>

