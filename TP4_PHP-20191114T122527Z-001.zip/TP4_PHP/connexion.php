<?php
try{
    $bdd = new PDO('mysql:host=localhost;dbname=tp4_php_test;charset=utf8','root','');
    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
}catch(Exception $e){
    die('Erreur :'.$e->getMessage());
}
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Connexion</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body>
    <center>
    <h1> Connexion :</h1>
    <form method="POST" action="connexion.php">
    <label for="pseudo">Pseudo : </label><input type="text" name="pseudo" id="pseudo"/><br><br>
    <label for="mdp">Mot de passe : </label><input type="password" name="mdp" id="mdp"/><br><br>
    <label for="case">Connexion automatique : </label><input type="checkbox" name="case" id="case"/><br><br>
    <input type="submit"/><br><br>

    <?php
    if(isset($_COOKIE['pseudo']) && isset($_COOKIE['mdp'])){
        $req = $bdd->prepare('select pass from membres where pseudo=?');
        $req->execute(array($_COOKIE['pseudo']));
        $donne = $req->fetch();
        if($_COOKIE['mdp'] == $donne['pass']){
            $req = $bdd->prepare('select id from membres where pseudo=?');
            $req->execute(array($_COOKIE['pseudo']));
            $donne = $req->fetch();
            session_start();
            $_SESSION['id']=$donne['id'];
            $_SESSION['pseudo']=$_COOKIE['pseudo'];
            echo 'Connectée grace au cookie';?> <br> <?php
            header('location: test.php');
        }
    }
    if(isset($_POST['pseudo']) && isset($_POST['mdp']) && $_POST['pseudo']!=NULL and $_POST['mdp']!=NULL){
        $req = $bdd->prepare('select count(*) as nbr from membres where pseudo=?');
        $req->execute(array($_POST['pseudo']));
        $donne = $req->fetch(PDO::FETCH_ASSOC);
        if($donne['nbr'] != 0){
            $req = $bdd->prepare('select pass from membres where pseudo=?');
            $req->execute(array($_POST['pseudo']));
            $donne = $req->fetch();
            $verify = password_verify($_POST['mdp'],$donne['pass']);
            if($verify == true){
                $req = $bdd->prepare('select id from membres where pseudo=?');
                $req->execute(array($_POST['pseudo']));
                $donne = $req->fetch();
                session_start();
                $_SESSION['id']=$donne['id'];
                $_SESSION['pseudo']=$_POST['pseudo'];
                echo 'Connectée';?> <br> <?php
                if($_POST['case'] == 'on'){
                    setcookie('pseudo',$_POST['pseudo'],time()+3600,null,null,false,true);
                    $req = $bdd->prepare('select pass from membres where pseudo=?');
                    $req->execute(array($_POST['pseudo']));
                    $donne = $req->fetch();
                    setcookie('mdp',$donne['pass'],time()+3600,null,null,false,true);
                    echo 'Cookie creer';
                    // echo $_COOKIE['pseudo'].' et '.$_COOKIE['mdp'];
                    header('location: test.php');
                }else{
                    header('location: test.php');
                }
            }else{
                echo 'Mauvais identifiant ou mot de passe';?> <br> <?php
            }
        }else{
            echo 'Mauvais identifiant ou mot de passe';?> <br> <?php
        }
    }else{
        echo 'Un ou plusieurs champs sont vide';?> <br> <?php
    }
    ?>

    </center>
</body>
</html>

