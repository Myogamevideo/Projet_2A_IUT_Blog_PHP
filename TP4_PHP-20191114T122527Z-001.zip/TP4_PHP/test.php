<?php
try{
    $bdd = new PDO('mysql:host=localhost;dbname=tp4_php_test;charset=utf8','root','');
    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
}catch(Exception $e){
    die('Erreur :'.$e->getMessage());
}
session_start();
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Test</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body>
    <center>
    <h1> Test :</h1>
    <a href="inscription.php">Inscription</a><br><br>
    <a href="connexion.php">Connexion</a><br><br>

    <?php
    if (isset($_SESSION['id']) AND isset($_SESSION['pseudo'])){
        echo 'Bonjour '.$_SESSION['pseudo'];?> <br><br> <?php
    }else{
        echo 'Veuillez vous inscire ou vous connectez'?> <br><br> <?php
    }
    ?>

    <form method="post" action="test.php">
    <input type="submit" value="Deconnection"/>
    
    <?php
    $_SESSION = array();
    session_destroy();
    setcookie('pseudo','');
    setcookie('mdp','');
    ?>
    </center>
</body>
</html>

