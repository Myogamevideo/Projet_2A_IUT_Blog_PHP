<?php
try{
    $bdd = new PDO('mysql:host=localhost;dbname=tp3_php_test;charset=utf8','root','');
    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
}catch(Exception $e){
    die('Erreur :'.$e->getMessage());
}
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Blog</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body>
    <h1> Blog :</h1>
    <?php 
        $reponse = $bdd->query('select id,contenu,titre, DAY(date_creation) AS jour, MONTH(date_creation) AS mois, YEAR(date_creation) AS annee, HOUR(date_creation) AS heure, MINUTE(date_creation) AS minute, SECOND(date_creation) AS seconde from billets order by id limit 5') or die(print_r($bdd->errorInfo()));
        while($donnees = $reponse->fetch()){
            echo 
            '<div class="news"> 
                <h3>'.htmlspecialchars($donnees['titre']).' le '.$donnees['jour'].'/'.$donnees['mois'].'/'.$donnees['annee'].' à '.$donnees['heure'].'h'.$donnees['minute'].'min'.$donnees['seconde'].'sec'.'</h3>
                <p>'.htmlspecialchars($donnees['contenu']).'</p>
                <a href="commentaires.php?id_billet='.$donnees['id'].'"> Commentaire </a>
            </div>';
            ?><br><?php
        }
        $reponse->closeCursor();
    ?>
    <div class="news">
    </div>
</body>
</html>