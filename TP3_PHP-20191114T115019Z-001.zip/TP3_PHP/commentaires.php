<?php
try{
    $bdd = new PDO('mysql:host=localhost;dbname=tp3_php_test;charset=utf8','root','');
    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
}catch(Exception $e){
    die('Erreur :'.$e->getMessage());
}
?>

<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>Blog</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body>
    <h1> Blog :</h1>
    <a href="index.php">Retour à la liste</a>
    <?php 
        $req = $bdd->prepare('select id,contenu,titre, DAY(date_creation) AS jour, MONTH(date_creation) AS mois, YEAR(date_creation) AS annee, HOUR(date_creation) AS heure, MINUTE(date_creation) AS minute, SECOND(date_creation) AS seconde from billets where id=?') or die(print_r($bdd->errorInfo()));
        $req->execute(array($_GET['id_billet']));
        $donnees=$req->fetch();
        echo 
            '<div class="news"> 
                <h3>'.htmlspecialchars($donnees['titre']).' le '.$donnees['jour'].'/'.$donnees['mois'].'/'.$donnees['annee'].' à '.$donnees['heure'].'h'.$donnees['minute'].'min'.$donnees['seconde'].'sec'.'</h3>
                <p>'.htmlspecialchars($donnees['contenu']).'</p>
            </div>';
        $req->closeCursor();
    ?>
    <br> 
    <h1>Commentaires :</h1>
    <?php
        $req = $bdd->prepare('select commentaire,auteur, DAY(date_commentaire) AS jour, MONTH(date_commentaire) AS mois, YEAR(date_commentaire) AS annee, HOUR(date_commentaire) AS heure, MINUTE(date_commentaire) AS minute, SECOND(date_commentaire) AS seconde from commentaires where id_billet=?') or die(print_r($bdd->errorInfo()));
        $req->execute(array($_GET['id_billet']));
        while($donnees=$req->fetch()){
            echo htmlspecialchars($donnees['auteur']).' le '.$donnees['jour'].'/'.$donnees['mois'].'/'.$donnees['annee'].' à '.$donnees['heure'].'h'.$donnees['minute'].'min'.$donnees['seconde'].'sec';
            ?><br><?php
            echo htmlspecialchars($donnees['commentaire'])
        ?><br><br><?php
        }
        $req->closeCursor();
    ?>
</body>
</html>